# After Me — Brand Assets v1.0

## Files included

### App Icon
- `icon-1024.svg` — Master app icon, 1024×1024px. Use this as the source for all icon sizes.
  Export at: 1024×1024 (App Store), 180×180 (iPhone @3x), 120×120 (iPhone @2x), 87×87 (Settings @3x), 80×80 (Spotlight @2x), 58×58 (Notification @2x), 40×40 (Spotlight @1x)

### Logo Concepts
- `logo-concept-a-dark.svg` — **Recommended** Envelope + amber key on warm slate. 400×400px.
- `logo-concept-b-light.svg` — Open document / legacy on warm white. 400×400px.
- `logo-concept-c-amber.svg` — Clock / time on amber. 400×400px.

### Brand Lockups (wordmark + icon + tagline)
- `brand-lockup-dark.svg` — Dark / warm slate background. 1200×280px. For dark backgrounds, website hero, press kit.
- `brand-lockup-light.svg` — Light / warm white background. 1200×180px. For light backgrounds, email headers, documents.
- `brand-lockup-amber.svg` — Amber background. 1200×144px. For accent sections, CTAs, social media headers.

### App Store Feature Banners (1320×620px each)
- `banner-1-hero.svg` — "The one conversation you keep putting off." — Hero/launch screen.
- `banner-2-privacy.svg` — "Never leave your phone." — Privacy & local-first.
- `banner-3-family-kit.svg` — "One QR code. Everything they need." — Family Kit magic.
- `banner-4-pricing.svg` — "Pay once. Yours forever." — No subscription.
- `banner-5-messages.svg` — "Write a letter. They'll read it when it matters most." — Personal messages.

## Colour Palette
| Name         | Hex       | Usage                                      |
|--------------|-----------|--------------------------------------------|
| Warm Slate   | `#2D3142` | Primary background, dark surfaces, text    |
| Amber Gold   | `#C9963A` | Accent, key element, CTAs, highlights      |
| Warm White   | `#FAF9F6` | Light backgrounds, icon foreground         |
| Soft Border  | `#E8E4DC` | Borders on light backgrounds               |

## Typography
- **Display / Wordmark:** Georgia or New York (iOS built-in serif). Use for all headlines and the wordmark.
- **Body:** SF Pro Text (system default on iOS). Use for all body copy and UI elements.

## Usage notes
- All files are SVG — scalable to any size without quality loss.
- To export PNG for App Store submission, open in Figma, Sketch, or Inkscape and export at 1× (the viewBox dimensions are the intended pixel sizes).
- For the app icon, Apple requires a PNG with no transparency for App Store submission. Export `icon-1024.svg` as a 1024×1024 PNG.
- The App Store banners are designed at 1320×620px — Apple's recommended screenshot size for iPhone 6.5" display. Resize as needed for other device sizes.

## Next steps
1. Import into Figma or Sketch for pixel-level refinement
2. Export icon PNG at all required sizes
3. Add to Xcode asset catalog (AppIcon.appiconset)
4. Use banners directly in App Store Connect > Screenshots
